#!/usr/bin/env bash
set -e
#name:TASK [upgrade avalanchego version] 
cp -f subnet-evm {{ .SubnetEVMBinaryPath }}
