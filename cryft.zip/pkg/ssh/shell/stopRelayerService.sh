#!/usr/bin/env bash
set -e
sudo systemctl stop awm-relayer
