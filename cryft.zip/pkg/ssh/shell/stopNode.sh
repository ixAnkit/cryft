#!/usr/bin/env bash
set -e
#name:TASK [stop node - stop avalanchego] 
sudo systemctl stop avalanchego
