#!/usr/bin/env bash
#name:TASK [restart node - restart avalanchego]
sudo systemctl restart avalanchego