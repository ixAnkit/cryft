#!/usr/bin/env bash
set -e
#name:TASK [start node - start avalanchego] 
sudo systemctl start avalanchego
