#!/usr/bin/env bash
#name:TASK [stop node - stop avalanchego] 
sudo pkill avalanchego || echo "avalanchego not running"
