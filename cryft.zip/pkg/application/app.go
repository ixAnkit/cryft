// Copyright (C) 2022, Ava Labs, Inc. All rights reserved.
// See the file LICENSE for licensing terms.
package application

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/MetalBlockchain/apm/apm"
	"github.com/ixAnkit/cryft/pkg/config"
	"github.com/ixAnkit/cryft/pkg/constants"
	"github.com/ixAnkit/cryft/pkg/models"
	"github.com/ixAnkit/cryft/pkg/monitoring"
	"github.com/ixAnkit/cryft/pkg/prompts"
	"github.com/ixAnkit/cryft/pkg/utils"
	"github.com/MetalBlockchain/metalgo/ids"
	"github.com/MetalBlockchain/metalgo/utils/logging"
	"github.com/MetalBlockchain/subnet-evm/core"

	"golang.org/x/exp/maps"
)

type Avalanche struct {
	Log        logging.Logger
	baseDir    string
	Conf       *config.Config
	Prompt     prompts.Prompter
	Apm        *apm.APM
	ApmDir     string
	Downloader Downloader
}

func New() *Avalanche {
	return &Avalanche{}
}

func (app *Avalanche) Setup(baseDir string, log logging.Logger, conf *config.Config, prompt prompts.Prompter, downloader Downloader) {
	app.baseDir = baseDir
	app.Log = log
	app.Conf = conf
	app.Prompt = prompt
	app.Downloader = downloader
}

func (app *Avalanche) GetRunFile() string {
	return filepath.Join(app.GetRunDir(), constants.ServerRunFile)
}

func (app *Avalanche) GetSnapshotsDir() string {
	return filepath.Join(app.baseDir, constants.SnapshotsDirName)
}

func (app *Avalanche) GetBaseDir() string {
	return app.baseDir
}

func (app *Avalanche) GetSubnetDir() string {
	return filepath.Join(app.baseDir, constants.SubnetDir)
}

func (app *Avalanche) GetNodesDir() string {
	return filepath.Join(app.baseDir, constants.NodesDir)
}

func (app *Avalanche) GetReposDir() string {
	return filepath.Join(app.baseDir, constants.ReposDir)
}

func (app *Avalanche) GetRunDir() string {
	return filepath.Join(app.baseDir, constants.RunDir)
}

func (app *Avalanche) GetServicesDir(baseDir string) string {
	if baseDir == "" {
		baseDir = app.baseDir
	}
	return filepath.Join(baseDir, constants.ServicesDir)
}

func (app *Avalanche) GetCustomVMDir() string {
	return filepath.Join(app.baseDir, constants.CustomVMDir)
}

func (app *Avalanche) GetPluginsDir() string {
	return filepath.Join(app.baseDir, constants.PluginDir)
}

// Remove all plugins from plugin dir
func (app *Avalanche) ResetPluginsDir() error {
	pluginDir := app.GetPluginsDir()
	installedPlugins, err := os.ReadDir(pluginDir)
	if err != nil {
		return err
	}
	for _, plugin := range installedPlugins {
		if err = os.Remove(filepath.Join(pluginDir, plugin.Name())); err != nil {
			return err
		}
	}
	return nil
}

func (app *Avalanche) GetAvalanchegoBinDir() string {
	return filepath.Join(app.baseDir, constants.AvalancheCliBinDir, constants.AvalancheGoInstallDir)
}

func (app *Avalanche) GetTeleporterBinDir() string {
	return filepath.Join(app.baseDir, constants.AvalancheCliBinDir, constants.TeleporterInstallDir)
}

func (app *Avalanche) GetAWMRelayerBinDir() string {
	return filepath.Join(app.baseDir, constants.AvalancheCliBinDir, constants.AWMRelayerInstallDir)
}

func (app *Avalanche) GetAWMRelayerStorageDir() string {
	return filepath.Join(app.GetRunDir(), constants.AWMRelayerStorageDir)
}

func (app *Avalanche) GetAWMRelayerConfigPath() string {
	return filepath.Join(app.GetRunDir(), constants.AWMRelayerConfigFilename)
}

func (app *Avalanche) GetAWMRelayerLogPath() string {
	return filepath.Join(app.GetRunDir(), constants.AWMRelayerLogFilename)
}

func (app *Avalanche) GetAWMRelayerRunPath() string {
	return filepath.Join(app.GetRunDir(), constants.AWMRelayerRunFilename)
}

func (app *Avalanche) GetAWMRelayerSnapshotConfsDir() string {
	return filepath.Join(app.GetSnapshotsDir(), constants.AWMRelayerSnapshotConfsDir)
}

func (app *Avalanche) GetAWMRelayerServiceDir(baseDir string) string {
	return filepath.Join(app.GetServicesDir(baseDir), constants.AWMRelayerInstallDir)
}

func (app *Avalanche) GetAWMRelayerServiceConfigPath(baseDir string) string {
	return filepath.Join(app.GetAWMRelayerServiceDir(baseDir), constants.AWMRelayerConfigFilename)
}

func (app *Avalanche) GetAWMRelayerServiceStorageDir(baseDir string) string {
	return filepath.Join(app.GetAWMRelayerServiceDir(baseDir), constants.AWMRelayerStorageDir)
}

func (app *Avalanche) GetExtraLocalNetworkDataPath() string {
	return filepath.Join(app.GetRunDir(), constants.ExtraLocalNetworkDataFilename)
}

func (app *Avalanche) GetExtraLocalNetworkSnapshotsDir() string {
	return filepath.Join(app.GetSnapshotsDir(), constants.ExtraLocalNetworkDataSnapshotsDir)
}

func (app *Avalanche) GetSubnetEVMBinDir() string {
	return filepath.Join(app.baseDir, constants.AvalancheCliBinDir, constants.SubnetEVMInstallDir)
}

func (app *Avalanche) GetUpgradeBytesFilepath(subnetName string) string {
	return filepath.Join(app.GetSubnetDir(), subnetName, constants.UpgradeBytesFileName)
}

func (app *Avalanche) GetCustomVMPath(subnetName string) string {
	return filepath.Join(app.GetCustomVMDir(), subnetName)
}

func (app *Avalanche) GetAPMVMPath(vmid string) string {
	return filepath.Join(app.GetAPMPluginDir(), vmid)
}

func (app *Avalanche) GetGenesisPath(subnetName string) string {
	return filepath.Join(app.GetSubnetDir(), subnetName, constants.GenesisFileName)
}

func (app *Avalanche) GetAvagoNodeConfigPath(subnetName string) string {
	return filepath.Join(app.GetSubnetDir(), subnetName, constants.NodeConfigFileName)
}

func (app *Avalanche) GetChainConfigPath(subnetName string) string {
	return filepath.Join(app.GetSubnetDir(), subnetName, constants.ChainConfigFileName)
}

func (app *Avalanche) GetAvagoSubnetConfigPath(subnetName string) string {
	return filepath.Join(app.GetSubnetDir(), subnetName, constants.SubnetConfigFileName)
}

func (app *Avalanche) GetSidecarPath(subnetName string) string {
	return filepath.Join(app.GetSubnetDir(), subnetName, constants.SidecarFileName)
}

func (app *Avalanche) GetNodeConfigPath(nodeName string) string {
	return filepath.Join(app.GetNodesDir(), nodeName, constants.NodeCloudConfigFileName)
}

func (app *Avalanche) GetNodeInstanceDirPath(nodeName string) string {
	return filepath.Join(app.GetNodesDir(), nodeName)
}

func (app *Avalanche) GetNodeInstanceAvaGoConfigDirPath(nodeName string) string {
	return filepath.Join(app.GetAnsibleDir(), nodeName)
}

func (app *Avalanche) GetAnsibleDir() string {
	return filepath.Join(app.GetNodesDir(), constants.AnsibleDir)
}

func (app *Avalanche) GetMonitoringDir() string {
	return filepath.Join(app.GetNodesDir(), constants.MonitoringDir)
}

func (app *Avalanche) GetMonitoringInventoryDir(clusterName string) string {
	return filepath.Join(app.GetAnsibleInventoryDirPath(clusterName), constants.MonitoringDir)
}

func (app *Avalanche) GetLoadTestInventoryDir(clusterName string) string {
	return filepath.Join(app.GetAnsibleInventoryDirPath(clusterName), constants.LoadTestDir)
}

func (app *Avalanche) CreateAnsibleDir() error {
	ansibleDir := app.GetAnsibleDir()
	if _, err := os.Stat(ansibleDir); os.IsNotExist(err) {
		err = os.Mkdir(ansibleDir, constants.DefaultPerms755)
		if err != nil {
			return err
		}
	}
	return nil
}

func (app *Avalanche) CreateAnsibleInventoryDir() error {
	inventoriesDir := filepath.Join(app.GetNodesDir(), constants.AnsibleInventoryDir)
	if _, err := os.Stat(inventoriesDir); os.IsNotExist(err) {
		err = os.Mkdir(inventoriesDir, constants.DefaultPerms755)
		if err != nil {
			return err
		}
	}
	return nil
}

func (app *Avalanche) GetClustersConfigPath() string {
	return filepath.Join(app.GetNodesDir(), constants.ClustersConfigFileName)
}

func (app *Avalanche) GetNodeBLSSecretKeyPath(instanceID string) string {
	return filepath.Join(app.GetNodeInstanceDirPath(instanceID), constants.BLSKeyFileName)
}

func (app *Avalanche) GetElasticSubnetConfigPath(subnetName string) string {
	return filepath.Join(app.GetSubnetDir(), subnetName, constants.ElasticSubnetConfigFileName)
}

func (app *Avalanche) GetKeyDir() string {
	return filepath.Join(app.baseDir, constants.KeyDir)
}

func (*Avalanche) GetTmpPluginDir() string {
	return os.TempDir()
}

func (app *Avalanche) GetAPMBaseDir() string {
	return filepath.Join(app.baseDir, "apm")
}

func (app *Avalanche) GetAPMLog() string {
	return filepath.Join(app.baseDir, constants.LogDir, constants.APMLogName)
}

func (app *Avalanche) GetAPMPluginDir() string {
	return filepath.Join(app.baseDir, constants.APMPluginDir)
}

func (app *Avalanche) GetKeyPath(keyName string) string {
	return filepath.Join(app.baseDir, constants.KeyDir, keyName+constants.KeySuffix)
}

func (app *Avalanche) GetUpgradeBytesFilePath(subnetName string) string {
	return filepath.Join(app.GetSubnetDir(), subnetName, constants.UpgradeBytesFileName)
}

func (app *Avalanche) GetDownloader() Downloader {
	return app.Downloader
}

func (*Avalanche) GetAvalanchegoCompatibilityURL() string {
	return constants.AvalancheGoCompatibilityURL
}

func (app *Avalanche) ReadUpgradeFile(subnetName string) ([]byte, error) {
	upgradeBytesFilePath := app.GetUpgradeBytesFilePath(subnetName)

	return app.readFile(upgradeBytesFilePath)
}

func (app *Avalanche) ReadLockUpgradeFile(subnetName string) ([]byte, error) {
	upgradeBytesLockFilePath := app.GetUpgradeBytesFilePath(subnetName) + constants.UpgradeBytesLockExtension

	return app.readFile(upgradeBytesLockFilePath)
}

func (app *Avalanche) WriteUpgradeFile(subnetName string, bytes []byte) error {
	upgradeBytesFilePath := app.GetUpgradeBytesFilePath(subnetName)

	return app.writeFile(upgradeBytesFilePath, bytes)
}

func (app *Avalanche) WriteLockUpgradeFile(subnetName string, bytes []byte) error {
	upgradeBytesLockFilePath := app.GetUpgradeBytesFilePath(subnetName) + constants.UpgradeBytesLockExtension

	return app.writeFile(upgradeBytesLockFilePath, bytes)
}

func (app *Avalanche) WriteGenesisFile(subnetName string, genesisBytes []byte) error {
	genesisPath := app.GetGenesisPath(subnetName)

	return app.writeFile(genesisPath, genesisBytes)
}

func (app *Avalanche) WriteAvagoNodeConfigFile(subnetName string, bs []byte) error {
	path := app.GetAvagoNodeConfigPath(subnetName)
	return app.writeFile(path, bs)
}

func (app *Avalanche) WriteChainConfigFile(subnetName string, bs []byte) error {
	path := app.GetChainConfigPath(subnetName)
	return app.writeFile(path, bs)
}

func (app *Avalanche) WriteAvagoSubnetConfigFile(subnetName string, bs []byte) error {
	path := app.GetAvagoSubnetConfigPath(subnetName)
	return app.writeFile(path, bs)
}

func (app *Avalanche) WriteNetworkUpgradesFile(subnetName string, bs []byte) error {
	path := app.GetUpgradeBytesFilepath(subnetName)
	return app.writeFile(path, bs)
}

func (app *Avalanche) GenesisExists(subnetName string) bool {
	genesisPath := app.GetGenesisPath(subnetName)
	_, err := os.Stat(genesisPath)
	return err == nil
}

func (app *Avalanche) AvagoNodeConfigExists(subnetName string) bool {
	path := app.GetAvagoNodeConfigPath(subnetName)
	_, err := os.Stat(path)
	return err == nil
}

func (app *Avalanche) ChainConfigExists(subnetName string) bool {
	path := app.GetChainConfigPath(subnetName)
	_, err := os.Stat(path)
	return err == nil
}

func (app *Avalanche) AvagoSubnetConfigExists(subnetName string) bool {
	path := app.GetAvagoSubnetConfigPath(subnetName)
	_, err := os.Stat(path)
	return err == nil
}

func (app *Avalanche) NetworkUpgradeExists(subnetName string) bool {
	path := app.GetUpgradeBytesFilepath(subnetName)
	_, err := os.Stat(path)
	return err == nil
}

func (app *Avalanche) ClustersConfigExists() bool {
	_, err := os.Stat(app.GetClustersConfigPath())
	return err == nil
}

func (app *Avalanche) SidecarExists(subnetName string) bool {
	sidecarPath := app.GetSidecarPath(subnetName)
	_, err := os.Stat(sidecarPath)
	return err == nil
}

func (app *Avalanche) SubnetConfigExists(subnetName string) bool {
	// There's always a sidecar, but imported subnets don't have a genesis right now
	return app.SidecarExists(subnetName)
}

func (app *Avalanche) KeyExists(keyName string) bool {
	keyPath := app.GetKeyPath(keyName)
	_, err := os.Stat(keyPath)
	return err == nil
}

func (app *Avalanche) CopyGenesisFile(inputFilename string, subnetName string) error {
	genesisBytes, err := os.ReadFile(inputFilename)
	if err != nil {
		return err
	}
	genesisPath := app.GetGenesisPath(subnetName)
	if err := os.MkdirAll(filepath.Dir(genesisPath), constants.DefaultPerms755); err != nil {
		return err
	}

	return os.WriteFile(genesisPath, genesisBytes, constants.WriteReadReadPerms)
}

func (app *Avalanche) CopyVMBinary(inputFilename string, subnetName string) error {
	vmBytes, err := os.ReadFile(inputFilename)
	if err != nil {
		return err
	}
	vmPath := app.GetCustomVMPath(subnetName)
	return os.WriteFile(vmPath, vmBytes, constants.DefaultPerms755)
}

func (app *Avalanche) CopyKeyFile(inputFilename string, keyName string) error {
	keyBytes, err := os.ReadFile(inputFilename)
	if err != nil {
		return err
	}
	keyPath := app.GetKeyPath(keyName)
	return os.WriteFile(keyPath, keyBytes, constants.WriteReadReadPerms)
}

func (app *Avalanche) LoadEvmGenesis(subnetName string) (core.Genesis, error) {
	genesisPath := app.GetGenesisPath(subnetName)
	jsonBytes, err := os.ReadFile(genesisPath)
	if err != nil {
		return core.Genesis{}, err
	}
	return app.LoadEvmGenesisFromJSON(jsonBytes)
}

func (*Avalanche) LoadEvmGenesisFromJSON(jsonBytes []byte) (core.Genesis, error) {
	var gen core.Genesis
	err := json.Unmarshal(jsonBytes, &gen)
	return gen, err
}

func (app *Avalanche) LoadRawGenesis(subnetName string) ([]byte, error) {
	genesisPath := app.GetGenesisPath(subnetName)
	return os.ReadFile(genesisPath)
}

func (app *Avalanche) LoadRawAvagoNodeConfig(subnetName string) ([]byte, error) {
	return os.ReadFile(app.GetAvagoNodeConfigPath(subnetName))
}

func (app *Avalanche) LoadRawChainConfig(subnetName string) ([]byte, error) {
	return os.ReadFile(app.GetChainConfigPath(subnetName))
}

func (app *Avalanche) LoadRawAvagoSubnetConfig(subnetName string) ([]byte, error) {
	return os.ReadFile(app.GetAvagoSubnetConfigPath(subnetName))
}

func (app *Avalanche) LoadRawNetworkUpgrades(subnetName string) ([]byte, error) {
	return os.ReadFile(app.GetUpgradeBytesFilepath(subnetName))
}

func (app *Avalanche) CreateSidecar(sc *models.Sidecar) error {
	if sc.TokenName == "" {
		sc.TokenName = constants.DefaultTokenName
		sc.TokenSymbol = constants.DefaultTokenSymbol
	}

	sidecarPath := app.GetSidecarPath(sc.Name)
	if err := os.MkdirAll(filepath.Dir(sidecarPath), constants.DefaultPerms755); err != nil {
		return err
	}

	// only apply the version on a write
	sc.Version = constants.SidecarVersion
	scBytes, err := json.MarshalIndent(sc, "", "    ")
	if err != nil {
		return err
	}

	return os.WriteFile(sidecarPath, scBytes, constants.WriteReadReadPerms)
}

func (app *Avalanche) LoadSidecar(subnetName string) (models.Sidecar, error) {
	sidecarPath := app.GetSidecarPath(subnetName)
	jsonBytes, err := os.ReadFile(sidecarPath)
	if err != nil {
		return models.Sidecar{}, err
	}

	var sc models.Sidecar
	err = json.Unmarshal(jsonBytes, &sc)

	if sc.TokenName == "" {
		sc.TokenName = constants.DefaultTokenName
		sc.TokenSymbol = constants.DefaultTokenSymbol
	}

	return sc, err
}

func (app *Avalanche) UpdateSidecar(sc *models.Sidecar) error {
	sc.Version = constants.SidecarVersion
	scBytes, err := json.MarshalIndent(sc, "", "    ")
	if err != nil {
		return err
	}

	sidecarPath := app.GetSidecarPath(sc.Name)
	return os.WriteFile(sidecarPath, scBytes, constants.WriteReadReadPerms)
}

func (app *Avalanche) UpdateSidecarNetworks(
	sc *models.Sidecar,
	network models.Network,
	subnetID ids.ID,
	transferSubnetOwnershipTxID ids.ID,
	blockchainID ids.ID,
	teleporterMessengerAddress string,
	teleporterRegistryAddress string,
) error {
	if sc.Networks == nil {
		sc.Networks = make(map[string]models.NetworkData)
	}
	sc.Networks[network.Name()] = models.NetworkData{
		SubnetID:                    subnetID,
		TransferSubnetOwnershipTxID: transferSubnetOwnershipTxID,
		BlockchainID:                blockchainID,
		RPCVersion:                  sc.RPCVersion,
		TeleporterMessengerAddress:  teleporterMessengerAddress,
		TeleporterRegistryAddress:   teleporterRegistryAddress,
	}
	if err := app.UpdateSidecar(sc); err != nil {
		return fmt.Errorf("creation of chains and subnet was successful, but failed to update sidecar: %w", err)
	}
	return nil
}

func (app *Avalanche) UpdateSidecarElasticSubnet(
	sc *models.Sidecar,
	network models.Network,
	subnetID ids.ID,
	assetID ids.ID,
	pchainTXID ids.ID,
	tokenName string,
	tokenSymbol string,
) error {
	if sc.ElasticSubnet == nil {
		sc.ElasticSubnet = make(map[string]models.ElasticSubnet)
	}
	partialTxs := sc.ElasticSubnet[network.Name()].Txs
	sc.ElasticSubnet[network.Name()] = models.ElasticSubnet{
		SubnetID:    subnetID,
		AssetID:     assetID,
		PChainTXID:  pchainTXID,
		TokenName:   tokenName,
		TokenSymbol: tokenSymbol,
		Txs:         partialTxs,
	}
	if err := app.UpdateSidecar(sc); err != nil {
		return err
	}
	return nil
}

func (app *Avalanche) UpdateSidecarPermissionlessValidator(
	sc *models.Sidecar,
	network models.Network,
	nodeID string,
	txID ids.ID,
) error {
	elasticSubnet := sc.ElasticSubnet[network.Name()]
	if elasticSubnet.Validators == nil {
		elasticSubnet.Validators = make(map[string]models.PermissionlessValidators)
	}
	elasticSubnet.Validators[nodeID] = models.PermissionlessValidators{TxID: txID}
	sc.ElasticSubnet[network.Name()] = elasticSubnet
	if err := app.UpdateSidecar(sc); err != nil {
		return err
	}
	return nil
}

func (app *Avalanche) UpdateSidecarElasticSubnetPartialTx(
	sc *models.Sidecar,
	network models.Network,
	txName string,
	txID ids.ID,
) error {
	if sc.ElasticSubnet == nil {
		sc.ElasticSubnet = make(map[string]models.ElasticSubnet)
	}
	partialTxs := make(map[string]ids.ID)
	if sc.ElasticSubnet[network.Name()].Txs != nil {
		partialTxs = sc.ElasticSubnet[network.Name()].Txs
	}
	partialTxs[txName] = txID
	sc.ElasticSubnet[network.Name()] = models.ElasticSubnet{
		Txs: partialTxs,
	}
	return app.UpdateSidecar(sc)
}

func (app *Avalanche) GetTokenName(subnetName string) string {
	sidecar, err := app.LoadSidecar(subnetName)
	if err != nil {
		return constants.DefaultTokenName
	}
	return sidecar.TokenName
}

func (app *Avalanche) GetTokenSymbol(subnetName string) string {
	sidecar, err := app.LoadSidecar(subnetName)
	if err != nil {
		return constants.DefaultTokenSymbol
	}
	return sidecar.TokenSymbol
}

func (app *Avalanche) GetSidecarNames() ([]string, error) {
	matches, err := os.ReadDir(app.GetSubnetDir())
	if err != nil {
		return nil, err
	}

	var names []string
	for _, m := range matches {
		if !m.IsDir() {
			continue
		}
		// a subnet dir could theoretically exist without a sidecar yet...
		if _, err := os.Stat(filepath.Join(app.GetSubnetDir(), m.Name(), constants.SidecarFileName)); err == nil {
			names = append(names, m.Name())
		}
	}
	return names, nil
}

func (*Avalanche) readFile(path string) ([]byte, error) {
	if err := os.MkdirAll(filepath.Dir(path), constants.DefaultPerms755); err != nil {
		return nil, err
	}

	return os.ReadFile(path)
}

func (*Avalanche) writeFile(path string, bytes []byte) error {
	if err := os.MkdirAll(filepath.Dir(path), constants.DefaultPerms755); err != nil {
		return err
	}

	return os.WriteFile(path, bytes, constants.WriteReadReadPerms)
}

func (app *Avalanche) CreateNodeCloudConfigFile(nodeName string, nodeConfig *models.NodeConfig) error {
	nodeConfigPath := app.GetNodeConfigPath(nodeName)
	if err := os.MkdirAll(filepath.Dir(nodeConfigPath), constants.DefaultPerms755); err != nil {
		return err
	}

	esBytes, err := json.MarshalIndent(nodeConfig, "", "    ")
	if err != nil {
		return err
	}

	return os.WriteFile(nodeConfigPath, esBytes, constants.WriteReadReadPerms)
}

func (app *Avalanche) CreateElasticSubnetConfig(subnetName string, es *models.ElasticSubnetConfig) error {
	elasticSubetConfigPath := app.GetElasticSubnetConfigPath(subnetName)
	if err := os.MkdirAll(filepath.Dir(elasticSubetConfigPath), constants.DefaultPerms755); err != nil {
		return err
	}

	esBytes, err := json.MarshalIndent(es, "", "    ")
	if err != nil {
		return err
	}

	return os.WriteFile(elasticSubetConfigPath, esBytes, constants.WriteReadReadPerms)
}

func (app *Avalanche) LoadElasticSubnetConfig(subnetName string) (models.ElasticSubnetConfig, error) {
	elasticSubnetConfigPath := app.GetElasticSubnetConfigPath(subnetName)
	jsonBytes, err := os.ReadFile(elasticSubnetConfigPath)
	if err != nil {
		return models.ElasticSubnetConfig{}, err
	}

	var esc models.ElasticSubnetConfig
	err = json.Unmarshal(jsonBytes, &esc)

	return esc, err
}

func (app *Avalanche) LoadClusterNodeConfig(nodeName string) (models.NodeConfig, error) {
	nodeConfigPath := app.GetNodeConfigPath(nodeName)
	jsonBytes, err := os.ReadFile(nodeConfigPath)
	if err != nil {
		return models.NodeConfig{}, err
	}
	var nodeConfig models.NodeConfig
	err = json.Unmarshal(jsonBytes, &nodeConfig)
	return nodeConfig, err
}

func (app *Avalanche) LoadClustersConfig() (models.ClustersConfig, error) {
	clustersConfigPath := app.GetClustersConfigPath()
	jsonBytes, err := os.ReadFile(clustersConfigPath)
	if err != nil {
		return models.ClustersConfig{}, err
	}
	var clustersConfig models.ClustersConfig
	var clustersConfigMap map[string]interface{}
	if err := json.Unmarshal(jsonBytes, &clustersConfigMap); err != nil {
		return models.ClustersConfig{}, err
	}
	v, ok := clustersConfigMap["Version"]
	if !ok {
		// backwards compatibility V0
		var clustersConfigV0 models.ClustersConfigV0
		if err := json.Unmarshal(jsonBytes, &clustersConfigV0); err != nil {
			return models.ClustersConfig{}, err
		}
		clustersConfig.Version = constants.ClustersConfigVersion
		clustersConfig.KeyPair = clustersConfigV0.KeyPair
		clustersConfig.GCPConfig = clustersConfigV0.GCPConfig
		clustersConfig.Clusters = map[string]models.ClusterConfig{}
		for clusterName, nodes := range clustersConfigV0.Clusters {
			clustersConfig.Clusters[clusterName] = models.ClusterConfig{
				Nodes:   nodes,
				Network: models.NewTahoeNetwork(),
			}
		}
		return clustersConfig, err
	}
	if v == constants.ClustersConfigVersion {
		if err := json.Unmarshal(jsonBytes, &clustersConfig); err != nil {
			return models.ClustersConfig{}, err
		}
		return clustersConfig, err
	}
	return models.ClustersConfig{}, fmt.Errorf("unsupported clusters config version %s", v)
}

func (app *Avalanche) WriteClustersConfigFile(clustersConfig *models.ClustersConfig) error {
	clustersConfigPath := app.GetClustersConfigPath()
	if err := os.MkdirAll(filepath.Dir(clustersConfigPath), constants.DefaultPerms755); err != nil {
		return err
	}

	clustersConfig.Version = constants.ClustersConfigVersion
	clustersConfigBytes, err := json.MarshalIndent(clustersConfig, "", "    ")
	if err != nil {
		return err
	}

	return os.WriteFile(clustersConfigPath, clustersConfigBytes, constants.WriteReadReadPerms)
}

func (*Avalanche) GetSSHCertFilePath(certName string) (string, error) {
	homeDir, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(homeDir, ".ssh", certName), nil
}

func (app *Avalanche) CheckCertInSSHDir(certName string) (bool, error) {
	certPath, err := app.GetSSHCertFilePath(certName)
	if err != nil {
		return false, err
	}
	_, err = os.Stat(certPath)
	if os.IsNotExist(err) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return true, nil
}

func (app *Avalanche) CreateMonitoringDir() error {
	monitoringDir := app.GetMonitoringDir()
	if !utils.DirectoryExists(monitoringDir) {
		err := os.MkdirAll(monitoringDir, constants.DefaultPerms755)
		if err != nil {
			return err
		}
	}
	return nil
}

func (app *Avalanche) CreateMonitoringDashboardDir() error {
	monitoringDashboardDir := app.GetMonitoringDashboardDir()
	if !utils.DirectoryExists(monitoringDashboardDir) {
		err := os.MkdirAll(monitoringDashboardDir, constants.DefaultPerms755)
		if err != nil {
			return err
		}
	}
	return nil
}

func (app *Avalanche) GetAnsibleInventoryDirPath(clusterName string) string {
	return filepath.Join(app.GetNodesDir(), constants.AnsibleInventoryDir, clusterName)
}

// CreateAnsibleNodeConfigDir creates the ansible node config directory specific for nodeID inside .avalanche-cli
func (app *Avalanche) CreateAnsibleNodeConfigDir(nodeID string) error {
	return os.MkdirAll(filepath.Join(app.GetAnsibleDir(), nodeID), constants.DefaultPerms755)
}

func (app *Avalanche) GetNodeConfigJSONFile(nodeID string) string {
	return filepath.Join(app.GetAnsibleDir(), nodeID, constants.NodeConfigJSONFile)
}

func (app *Avalanche) GetClusterYAMLFilePath(clusterName string) string {
	return filepath.Join(app.GetAnsibleInventoryDirPath(clusterName), constants.ClusterYAMLFileName)
}

func (app *Avalanche) GetMonitoringDashboardDir() string {
	return filepath.Join(app.GetMonitoringDir(), constants.DashboardsDir)
}

func (app *Avalanche) SetupMonitoringEnv() error {
	err := os.RemoveAll(app.GetMonitoringDir())
	if err != nil {
		return err
	}
	err = app.CreateMonitoringDir()
	if err != nil {
		return err
	}
	err = app.CreateMonitoringDashboardDir()
	if err != nil {
		return err
	}
	return monitoring.Setup(app.GetMonitoringDir())
}

func (app *Avalanche) ClusterExists(clusterName string) (bool, error) {
	clustersConfig := models.ClustersConfig{}
	if app.ClustersConfigExists() {
		var err error
		clustersConfig, err = app.LoadClustersConfig()
		if err != nil {
			return false, err
		}
	}
	_, ok := clustersConfig.Clusters[clusterName]
	return ok, nil
}

func (app *Avalanche) GetClusterConfig(clusterName string) (models.ClusterConfig, error) {
	exists, err := app.ClusterExists(clusterName)
	if err != nil {
		return models.ClusterConfig{}, err
	}
	if !exists {
		return models.ClusterConfig{}, fmt.Errorf("cluster %q does not exists", clusterName)
	}
	clustersConfig, err := app.LoadClustersConfig()
	if err != nil {
		return models.ClusterConfig{}, err
	}
	clusterConfig := clustersConfig.Clusters[clusterName]
	clusterConfig.Network = models.NewNetworkFromCluster(clusterConfig.Network, clusterName)
	return clusterConfig, nil
}

func (app *Avalanche) SetClusterConfig(clusterName string, clusterConfig models.ClusterConfig) error {
	clustersConfig, err := app.LoadClustersConfig()
	if err != nil {
		return err
	}
	clustersConfig.Clusters[clusterName] = clusterConfig
	return app.WriteClustersConfigFile(&clustersConfig)
}

func (app *Avalanche) GetClusterNetwork(clusterName string) (models.Network, error) {
	clusterConfig, err := app.GetClusterConfig(clusterName)
	if err != nil {
		return models.UndefinedNetwork, err
	}
	return clusterConfig.Network, nil
}

func (app *Avalanche) ListClusterNames() ([]string, error) {
	if !app.ClustersConfigExists() {
		return []string{}, nil
	}
	clustersConfig, err := app.LoadClustersConfig()
	if err != nil {
		return []string{}, err
	}
	return maps.Keys(clustersConfig.Clusters), nil
}
